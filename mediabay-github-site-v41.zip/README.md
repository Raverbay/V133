# MediaBay — GitHub Pages V41

Logo fix:
- the baked black square has been removed from the logo asset itself;
- `mediabay-symbol-transparent.png` is a real transparent PNG;
- the visible mark is white and integrates directly into the header;
- no black rectangle is required or simulated by CSS.

Replace the HTML files and add `mediabay-symbol-transparent.png` to the repository.
